<?php

namespace CustomReports\DownloadRports\Model\ResourceModel\DownloadRports;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{

    protected function _construct()
    {
        $this->_init('CustomReports\DownloadRports\Model\DownloadRports', 'CustomReports\DownloadRports\Model\ResourceModel\DownloadRports');
    }

}

?>
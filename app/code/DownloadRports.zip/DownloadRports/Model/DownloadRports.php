<?php

namespace CustomReports\DownloadRports\Model;

class DownloadRports extends \Magento\Framework\Model\AbstractModel
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('CustomReports\DownloadRports\Model\ResourceModel\DownloadRports');
    }
}
?>
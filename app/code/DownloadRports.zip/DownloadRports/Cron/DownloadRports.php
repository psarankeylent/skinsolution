<?php

declare(strict_types=1);

namespace CustomReports\DownloadRports\Cron;

class DownloadRports
{

    protected $logger;

    /**
     * Constructor
     *
     * @param \Psr\Log\LoggerInterface $logger
     */
    public function __construct(
        \CustomReports\DownloadRports\Model\DownloadRportsFactory $downloadRportsFactory,
        \Psr\Log\LoggerInterface $logger
    )
    {
        $this->logger = $logger;
        $this->downloadRportsFactory = $downloadRportsFactory;
    }

    /**
     * Execute the cron
     *
     * @return void
     */
    public function execute()
    {
        $this->logger->addInfo("Cronjob DownloadRports is executed.");

        $downloadRports = $this->downloadRportsFactory->create()
                    ->getCollection()
                    ->addFieldToFilter("download_status", 0)
                    ->getFirstItem();

                    

    }
}


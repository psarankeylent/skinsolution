/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

var config = {
    map: {
        '*': {
            'Magento_Ui/js/grid/massactions' : 'Renewal_ExpirationReport/js/grid/custommassactions'
        }
    }
};

var config = {
    map: {
        '*': {
            additionalcontent:'Ssmd_ProductAdditionalContent/js/additionalcontent'
        }
    }
};

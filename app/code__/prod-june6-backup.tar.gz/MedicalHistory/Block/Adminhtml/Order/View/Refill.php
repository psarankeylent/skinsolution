<?php

namespace Ssmd\MedicalHistory\Block\Adminhtml\Order\View;

use Magento\Backend\Block\Template\Context;
use Magento\Framework\Registry;
use Magento\Backend\Block\Template;
//use Enhance\Prescriptions\Model\CustomerPrescriptionOrders as CustomerPrescriptionOrders;

class Refill extends Template
{
    protected $medicalHistoryHelper;
    protected $resultJsonFactory;
    protected $_customerVisitor;
    protected $orderFactory;
    protected $medicalHistoryFactory;

    public function __construct(
        Context $context,
        Registry $registry,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        \Ssmd\MedicalHistory\Helper\Data $medicalHistoryHelper,
        \Ssmd\MedicalHistory\Model\CustomerMedicalHistoryFactory $medicalHistoryFactory
    )
    {
        $this->_registry = $registry;
        $this->orderFactory = $orderFactory;
        $this->medicalHistoryHelper = $medicalHistoryHelper;
        $this->medicalHistoryFactory = $medicalHistoryFactory;
        return parent::__construct($context);
    }
    /**
     * Retrieve order model instance
     *
     * @return \Magento\Sales\Model\Order
     */
    public function getOrder()
    {
        return $this->_registry->registry('current_order');
    }
    public function getAnsweredQuestions(){
        $order = $this->getOrder();
        $order_id =  $order->getId();
        //echo "workinggg"; die;
        /*$prescriptionOrderItem = $this->customerPrescriptionOrders->getCollection()
            ->addFieldToFilter("order_id", $order_id)
            ->getFirstItem();
        //print_r($prescriptionOrderItem->getData());
        //die;
        $unique_response_id = $prescriptionOrderItem
            ->getData('unique_response_id');
        $prescription_id = $prescriptionOrderItem
            ->getData('prescription_id');*/

        $unique_response_id = 'aa690d6b2565f31';

         //$prescriptionData = $this->prescriptions->getCollection()
           // ->addFieldToFilter("prescription_id", $prescription_id)->getFirstItem();
        
       
        $collectionCR = $this->medicalHistoryHelper->getCustomerResponsesCollection();
    
        $collectionCR->addFieldToFilter('response_status', 1);
        $collectionCR->addFieldToFilter('unique_response_id', $unique_response_id);
        //$collectionCR->setOrder('id','DESC');
        //$collectionCR->getSelect()->order('id DESC');
        //print_r($collectionCR->getData()); die;
        $dataItems = $groupIds = $dataByGroupID = [];
        foreach ($collectionCR as $_item){
            $itemData = $_item->getData();
            $questionId = $itemData['question_id'];
            $questionData = $this->medicalHistoryHelper->getQuestionById($questionId);
            $questionResponseData = $this->medicalHistoryHelper->getResponseTypeById($itemData['response_id']);

            $groupData = $this->medicalHistoryHelper->getGroups($questionId);
            //print_r($questionData->getData());
            //print_r($groupData->getData());
            //die;
            $itemData['question_data'] = $questionData->getData();
            $groupsData = [];
            foreach ($groupData as $_group) {
                //$groupsData[$_group->getGroupId()]['group_data'] = $_group->getData();
                $responseTypeData = $this->medicalHistoryHelper->getResponseTypes($_group->getGroupId())->getData();
                $groupsData[$_group->getGroupId()]['response_data'] = $responseTypeData;
                //$responses[] = $this->getResponseTypes($_group->getGroupId())->getData();
                $itemData['question_data']['group_text'][$_group->getGroupId()] = $_group->getData('group_text');
                $itemData['question_data']['group_subtext'][$_group->getGroupId()] = $_group->getData('group_subtext');
            }
            //$itemData['groups'] = $groupsData;
            //$itemData['group_info'] = $groupsData;
            
            $itemData['question_response_data'] = $questionResponseData->getData();
            $dataItems[] = $itemData;
            $groupIds[] = $itemData['group_id'];
            $dataByGroupID[$itemData['group_id']][] =  $itemData;
        }
        ksort($dataByGroupID);
        //print_r($dataByGroupID);
        return $dataByGroupID;

    }

    // Return data array of Customer Medical Histroy
    public function getMedicalHistoryByOrder(){
        $order = $this->getOrder();
        $orderId =  $order->getId();
        
        $medicalHistoryCollection = $this->medicalHistoryFactory->create()->getCollection();
    
        //$medicalHistoryCollection->addFieldToFilter('unique_id', $order->getData('unique_id'));
        $medicalHistoryCollection->addFieldToFilter('order_number', $order->getData('increment_id'));
        //$medicalHistoryCollection->setOrder('id','DESC');

        //echo "<pre>"; print_r($medicalHistoryCollection->getData()); exit;
        $dt = $medicalHistoryCollection->getData();
        $data = [];
        foreach ($dt as $key => $value) {
            $data[] = $value;
            $questionData = $this->medicalHistoryHelper->getQuestionById($value['question_id']);
            $data[$key]['question_subtext'] = $questionData->getQuestionSubtext(); 
            $data[$key]['response_type'] = $questionData->getResponseType(); 
        }
        //echo "<pre>"; print_r($data); exit;

        return $data;

    }

    public function getAnsweredQuestionsByUniqString($unique_response_id){
        
       
        $collection = $this->medicalHistoryHelper->getCustomerResponsesByUniqResId($unique_response_id);
        $dataItems = $groupIds = $dataByGroupID = [];
        foreach ($collection as $_item){
            $itemData = $_item->getData();
            $questionId = $itemData['question_id'];
            $questionData = $this->medicalHistoryHelper->getQuestionById($questionId);
            $questionResponseData = $this->medicalHistoryHelper->getResponseTypeById($itemData['response_id']);

            $groupData = $this->medicalHistoryHelper->getGroups($questionId);
            $groupsData = [];
            foreach ($groupData as $_group) {
                $groupsData[$_group->getGroupId()]['group_data'] = $_group->getData();
                $responseTypeData = $this->medicalHistoryHelper->getResponseTypes($_group->getGroupId())->getData();
                $groupsData[$_group->getGroupId()]['response_data'] = $responseTypeData;
                //$responses[] = $this->getResponseTypes($_group->getGroupId())->getData();
            }
            //$itemData['groups'] = $groupsData;
            $itemData['question_data'] = $questionData->getData();
            $itemData['question_response_data'] = $questionResponseData->getData();
            $dataItems[] = $itemData;
            $groupIds[] = $itemData['group_id'];
            $dataByGroupID[$itemData['group_id']][] =  $itemData;
        }
        ksort($dataByGroupID);
        //print_r($dataByGroupID);
        return $dataByGroupID;

    }

}

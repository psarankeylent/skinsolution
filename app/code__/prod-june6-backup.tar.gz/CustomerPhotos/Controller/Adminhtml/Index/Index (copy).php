<?php
namespace Ssmd\CustomerPhotos\Controller\Adminhtml\Index;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;


class Index extends Action
{
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;

    /**
     * @var \Magento\Backend\Model\View\Result\Page
     */
    protected $resultPage;

    /**
     * @param Context $context
     * @param PageFactory $resultPageFactory
     */

    protected $_fileUploaderFactory;
    protected $_messageManager;
    protected $_customerphotosFactory;
    protected $prescriptionCustomerPhotosOrdersFactory;
    protected $storeManager;
    protected $_encryptor;
    protected $_dataHelper;
    protected $orderFactory;

    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        \Magento\Framework\Filesystem $filesystem,
        \Magento\MediaStorage\Model\File\UploaderFactory $fileUploaderFactory,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        \Ssmd\CustomerPhotos\Model\CustomerPhotosFactory $customerPhotosFactory,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Encryption\EncryptorInterface $encryptor,
        \Ssmd\CustomerPhotos\Helper\Data $dataHelper,
        \Magento\Sales\Model\OrderFactory $orderFactory
    )
    {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
        $this->_mediaDirectory = $filesystem->getDirectoryWrite(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
        $this->_fileUploaderFactory = $fileUploaderFactory;
        $this->_messageManager = $messageManager;
        $this->_customerPhotosFactory = $customerPhotosFactory;
        $this->storeManager = $storeManager;
        $this->_encryptor = $encryptor;
        $this->_dataHelper = $dataHelper;
        $this->orderFactory = $orderFactory;
    }

    public function execute()
    {
        //echo "called admin"; exit;
        $this->resultPage = $this->resultPageFactory->create();

        try{

            // Customer ID

            $response_array = array();
            $extTypes = array('jpg','jpeg','png','heic');
            $customerId = $this->getRequest()->getParam('customer_id');
            //$incrementId = $this->getRequest()->getParam('increment_id');

            // Required Dir 'secure' will create if not created
            $secureDir  =  $this->_dataHelper->getRootDirPath().'secure';
            if (!file_exists($secureDir)) {
                mkdir($secureDir, 0777, true);
            }

            // Required Dir 'customer' will create if not created
            $customerDir  =  $secureDir.'/customer';
            if (!file_exists($customerDir)) {
                mkdir($customerDir, 0777, true);
            }

            // Required Dir 'customer' will create if not created
            $photosDir  =  $customerDir.'/photos';
            if (!file_exists($photosDir)) {
                mkdir($photosDir, 0777, true);
            }
             
            for($i=0; $i < strlen($customerId); $i++) {

                if (!file_exists($photosDir.'/'.$customerId[$i])) {

                   // $temp[$i-1] = $customerId[$i];
                    mkdir($photosDir.'/'.$customerId[$i], 0777, true);
                   // $photosDir = 
                    $photosDir = $photosDir.'/'.$customerId[$i];
                }
            }

            $this->createCustomerIDRecursiveDir($photosDir, $customerId);

            echo "ff"; exit;

            // These hidden varaibles needed for saving new record in 'prescription_customer_photo_orders' table. If this order entrey not found create an entery in customer_photo and photo_order table



            if($this->getRequest()->getParam('photo_id') != "")
            {

                $photoId = $this->getRequest()->getParam('photo_id');

                //$customerPrescriptionId = 1;
                //$prescriptionId = 1;
                $incrementId = $this->getRequest()->getParam('increment_id');
                $order = $this->orderFactory->create()->loadByIncrementId($incrementId);

                //$itemId = $this->getRequest()->getParam('item_id');

            }
            else
            {
                $photoId = null;
                $incrementId = $this->getRequest()->getParam('increment_id');
                $order = $this->orderFactory->create()->loadByIncrementId($incrementId);
               
            }



//===================================================================== FACE PHOTO UPLOAD CODE ================================================================================================

            if(!empty($this->getRequest()->getParam('face_photo_type')))
            {

                $face_files = $this->getRequest()->getFiles('face_photo');
                $facePhotoPhotoType = $this->getRequest()->getParam('face_photo_type');


                $fileName_facePhoto = ($face_files && array_key_exists('name', $face_files)) ? $face_files['name'] : null;
                $fileName_facePhoto = str_replace(" ", "_", strtolower($fileName_facePhoto));
                if ($face_files && $fileName_facePhoto) {


                    /** @var $uploader \Magento\MediaStorage\Model\File\UploaderFactory */
                    $uploader = $this->_fileUploaderFactory->create(['fileId' => 'face_photo']);

                    // set allowed file extensions
                    $uploader->setAllowedExtensions(['jpg','jpeg','png','heic']);

                    // Allow folder creation if not exists
                    $uploader->setAllowCreateFolders(true);

                    // Rename file if already exists it set true(like filename.jpg, filename_1.jpg etc), and set false it overrides into dir
                    $uploader->setAllowRenameFiles(false);


                    // ================== Encrypted filename with MD5 hase ========================

                    //$face_fileArr = explode('.',$fileName_facePhoto);
                    //$face_fileNameWithoutExt = $face_fileArr[0];
                    //$face_fileExt = $face_fileArr[1];

                    $fileName_facePhoto = preg_replace("/[^A-Za-z0-9-.]/", '_', $fileName_facePhoto);
                    $newStr = explode('.', $fileName_facePhoto);
                    $face_fileExt = end($newStr);
                    $face_fileNameWithoutExt = str_replace('.', '', $fileName_facePhoto);

                    $face_fileNameWithoutExt = md5($face_fileNameWithoutExt);
                    $fileName_facePhoto = $face_fileNameWithoutExt.'.'.$face_fileExt;

                    // ================== Encrypted filename with MD5 hase ========================



                    // =================== Image Resize before save to directory and db ==============================

                    if($face_fileExt == 'heic')
                    {

                        // heic directory creation
                        $heicDir = $custDirFaceHeadPhoto.'/heic';
                        if (!file_exists($heicDir)) {
                            mkdir($heicDir, 0777, true);
                        }

                        //echo $fileName; exit;
                        $result = $uploader->save(
                            $this->_mediaDirectory->getAbsolutePath().'images/facePhotoDir/'.$customerId.'/heic', $fileName_facePhoto);
                        //print_r($result);
                        //exit;


                        $uploadedFile = $this->_mediaDirectory->getAbsolutePath().'images/facePhotoDir/'.$customerId.'/heic/'.$fileName_facePhoto;


                        // code for Magick library start here

                        //$newFileName = $files['tmp_name'];
                        $newFileName = $uploadedFile;

                        $imagick = new \Imagick($newFileName);

                        //$imagick->clear();

                        // convert to jpg
                        $imagick->setImageFormat('jpg');
                        $imagick->readImage($newFileName);

                        $f_name_arr = explode('.', $fileName_facePhoto);
                        $f_name = $f_name_arr[0];   // extract name from '08563e541993a69209d4d3cf078861df.heic'
                        $fileName_facePhoto = $f_name.'.jpg';


                        $imagick->writeImage($this->_mediaDirectory->getAbsolutePath().'images/facePhotoDir/'.$customerId.'/'.$fileName_facePhoto);


                        // code for Magick library end here

                        // Save image again out of 'heic' dir after resize
                        $uploadedFile = $this->_mediaDirectory->getAbsolutePath().'images/facePhotoDir/'.$customerId.'/'.$fileName_facePhoto;

                        $resizedImgURL = $this->_dataHelper->imageResizeBeforeSaveImage($fileName_facePhoto, $uploadedFile, 'facePhotoDir', $customerId);

                    }
                    else{
                        $uploadedFile = $face_files['tmp_name'];
                        $resizedImgURL = $this->_dataHelper->imageResizeBeforeSaveImage($fileName_facePhoto, $uploadedFile, 'facePhotoDir', $customerId);
                    }

                    // =================== Image Resize before save to directory and db ==============================


                    // Old record needs to do be status zero of 'prescription_customer_photo' table
                    if($photoId != "" || $photoId != null )
                    {
                        $facesavephotoModel = $this->_customerPhotosFactory->create()->load($photoId);
                                $facesavephotoModel->setStatus(0)
                                                      ->save();
                    }

                    // New record will be adding by creating new Object
                    $facesavephotoModelNewObj = $this->_customerPhotosFactory->create();
                    $facesavephotoModelNewObj->setCustomerId($customerId)
                        ->setPhotoType($facePhotoPhotoType)
                        ->setPath($fileName_facePhoto)
                        ->setSourceSystem($face_files['tmp_name'])
                        ->setStatus(1)
                        ->setIncrementId($incrementId)
                        ->setCreatedAt(date('Y-m-d h:i:s'))
                        ->save();

                  

                }
                else
                {
                    $response_array['face_image_path'] = "";
                }



                // ============================== Image encrypted code start here ====================================

                $response_array['face_image_path'] = '';

                try{

                    //$url = '/var/www/enhance/pub/media/images/facePhotoDir/'.$customerId.'/'.$fileName_facePhoto;
                    $url = $this->_dataHelper->getFacephotoDirUrl().$customerId.'/'.$fileName_facePhoto;
                    $type = pathinfo($url, PATHINFO_EXTENSION);
                    $data = file_get_contents($url);
                    $imageData = base64_encode($data);
                    $imagePath = 'data: '.mime_content_type($url).';base64,'.$imageData;


                    if($fileName_facePhoto != "" || $fileName_facePhoto != null)
                    {
                        $response_array['face_image_path'] = '<a data-fancybox="gallery" href="'.$imagePath.'"><img src="'.$imagePath.'" style="max-height: 185px"></a>';
                        // Getting new record's customer_photo_id

                        //$response_array['face_customerPhotoId'] = $newCustomerPhotoId;
                        $response_array['face_image_success'] = 1;
                    }
                    else
                    {
                        $response_array['face_image_path'] = '';
                        $response_array['face_image_success'] = 2;
                    }

                    echo json_encode($response_array);
                    exit;


                }catch (\Exception $e) {

                    // echo $e->getMessage(); exit;
                    $response_array['face_image_success'] = 2;
                }
                // ============================== Image encrypted code end here ========================================
            }




//====================================================================== Govt PHOTOID UPLOAD CODE ==============================================================================================

            if(!empty($this->getRequest()->getParam('govt_photo_type')))
            {

                $files = $this->getRequest()->getFiles('govt_photo');
                $govtPhotoType = $this->getRequest()->getParam('govt_photo_type');



                $fileName = ($files && array_key_exists('name', $files)) ? $files['name'] : null;
                $fileName = str_replace(" ", "_", strtolower($fileName));
                if ($files && $fileName) {


                    /** @var $uploader \Magento\MediaStorage\Model\File\UploaderFactory */
                    $uploader = $this->_fileUploaderFactory->create(['fileId' => 'govt_photo']);

                    // set allowed file extensions
                    $uploader->setAllowedExtensions(['jpg','jpeg','png','heic']);

                    // Allow folder creation if not exists
                    $uploader->setAllowCreateFolders(true);

                    // Rename file if already exists it set true(like filename.jpg, filename_1.jpg etc), and set false it overrides into dir
                    $uploader->setAllowRenameFiles(false);


                    // ================== Encrypted filename with MD5 hase ========================

                    $fileName = preg_replace("/[^A-Za-z0-9-.]/", '_', $fileName);
                    $newStr = explode('.', $fileName);
                    $fileExt = end($newStr);
                    $fileNameWithoutExt = str_replace('.', '', $fileName);

                    $fileNameWithoutExt = md5($fileNameWithoutExt);
                    $fileName = $fileNameWithoutExt.'.'.$fileExt;

                    // ================== Encrypted filename with MD5 hase ========================



                    // =================== Image Resize before save to directory and db ==============================


                    // If image type is heic then
                    if($fileExt == 'heic')
                    {
                        // heic directory creation
                        $heicDir = $custDirPhotoId.'/heic';
                        if (!file_exists($heicDir)) {
                            mkdir($heicDir, 0777, true);
                        }

                        //echo $fileName; exit;
                        $result = $uploader->save(
                            $this->_mediaDirectory->getAbsolutePath().'images/govtIssuedPhoto/'.$customerId.'/heic', $fileName);
                        //print_r($result);
                        //exit;


                        $uploadedFile = $this->_mediaDirectory->getAbsolutePath().'images/govtIssuedPhoto/'.$customerId.'/heic/'.$fileName;


                        // code for Magick library start here

                        //$newFileName = $files['tmp_name'];
                        $newFileName = $uploadedFile;

                        $imagick = new \Imagick($newFileName);

                        //$imagick->clear();

                        // convert to jpg
                        $imagick->setImageFormat('jpg');
                        $imagick->readImage($newFileName);

                        $f_name_arr = explode('.', $fileName);
                        $f_name = $f_name_arr[0];   // extract name from '08563e541993a69209d4d3cf078861df.heic'
                        $fileName = $f_name.'.jpg';


                        $imagick->writeImage($this->_mediaDirectory->getAbsolutePath().'images/govtIssuedPhoto/'.$customerId.'/'.$fileName);


                        // code for Magick library end here

                        // Save image again out of 'heic' dir after resize
                        $uploadedFile = $this->_mediaDirectory->getAbsolutePath().'images/govtIssuedPhoto/'.$customerId.'/'.$fileName;

                        $resizedImgURL = $this->_dataHelper->imageResizeBeforeSaveImage($fileName, $uploadedFile, 'govtIssuedPhoto', $customerId);

                    }
                    else{

                        $uploadedFile = $files['tmp_name'];
                        $resizedImgURL = $this->_dataHelper->imageResizeBeforeSaveImage($fileName, $uploadedFile, 'govtIssuedPhoto', $customerId);
                    }

                    // =================== Image Resize before save to directory and db ==============================



                    // Old record needs to do be status zero of 'prescription_customer_photo' table
                    $photoModel = $this->_customerPhotosFactory->create();
                    if($photoId != "" || $photoId != null)
                    {

                        $photoModel->load($photoId)
                                   ->setStatus(0)
                                   ->save();
                    }

                    // New record will be adding by creating new Object
                   
                    $photoModelNewObj = $this->_customerPhotosFactory->create();
                    $photoModelNewObj->setCustomerId($customerId)
                                    ->setPhotoType($govtPhotoType)
                                    ->setPath($fileName)
                                    ->setSourceSystem($files['tmp_name'])
                                    ->setStatus(1)
                                    ->setIncrementId($incrementId)
                                    ->setCreatedAt(date('Y-m-d h:i:s'))
                                    ->save();


                }
                else
                {
                    $response_array['photoid_image_path'] = "";
                }



                // ============================== Image encrypted code start here ====================================

                $response_array['photoid_image_path'] = '';

                try{

                    //$url = '/var/www/enhance/pub/media/images/govtIssuedPhoto/'.$customerId.'/'.$fileName;
                    $url = $this->_dataHelper->getGovtPhotoDirUrl().$customerId.'/'.$fileName;
                    $type = pathinfo($url, PATHINFO_EXTENSION);
                    $data = file_get_contents($url);
                    $imageData = base64_encode($data);
                    $imagePath = 'data: '.mime_content_type($url).';base64,'.$imageData;


                    if($fileName != "" || $fileName != null)
                    {
                        $response_array['photoid_image_path'] = '<a data-fancybox="gallery" href="'.$imagePath.'"><img src="'.$imagePath.'" style="max-height: 185px"></a>';
                        //$response_array['govt_customerPhotoId'] = $newCustomerPhotoId_govtId;
                        $response_array['success'] = 1;


                    }
                    else
                    {
                        $response_array['photoid_image_path'] = '';
                        $response_array['success'] = 2;
                    }

                    echo json_encode($response_array);
                    exit;


                }catch (\Exception $e) {

                     echo $e->getMessage(); exit;
                    $response_array['errorMessage'] = $e->getMessage();
                    $response_array['success'] = 2;
                }

                // ============================== Image encrypted code end here ========================================
            }




        } catch (\Exception $e) {
            //echo $e->getMessage(); exit;
            $response_array['error'] = 1;
            $response_array['errorMessage'] = $e->getMessage();

            echo json_encode($response_array);
            exit;

            $this->_messageManager->addError('Only jpg, jpeg, png and heic file type is allowed.');
        }

        return $this->resultPage;
    }

    public function createCustomerIDRecursiveDir($path) {

        $str = explode('/', $path);
        $dir = '';
        foreach ($str as $part) {
            $dir .= '/'. $part ;
            if (!is_dir($dir) && strlen($dir) > 0 && strpos($dir, ".") == false) {
                mkdir($dir , 0777, true);
            }elseif(!file_exists($dir) && strpos($dir, ".") !== false){
               touch($dir);
            }
        }
    }
}

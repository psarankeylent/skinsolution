<?php
namespace Ssmd\CustomerPhotos\Controller\Adminhtml\Index;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;


class Index extends Action
{
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;

    /**
     * @var \Magento\Backend\Model\View\Result\Page
     */
    protected $resultPage;

    /**
     * @param Context $context
     * @param PageFactory $resultPageFactory
     */

    protected $_fileUploaderFactory;
    protected $_messageManager;
    protected $_customerphotosFactory;
    protected $prescriptionCustomerPhotosOrdersFactory;
    protected $storeManager;
    protected $_encryptor;
    protected $_dataHelper;
    protected $orderFactory;

    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        \Magento\Framework\Filesystem $filesystem,
        \Magento\MediaStorage\Model\File\UploaderFactory $fileUploaderFactory,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        \Ssmd\CustomerPhotos\Model\CustomerPhotosFactory $customerPhotosFactory,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Encryption\EncryptorInterface $encryptor,
        \Ssmd\CustomerPhotos\Helper\Data $dataHelper,
        \Magento\Sales\Model\OrderFactory $orderFactory
    )
    {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
        $this->_mediaDirectory = $filesystem->getDirectoryWrite(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
        $this->_fileUploaderFactory = $fileUploaderFactory;
        $this->_messageManager = $messageManager;
        $this->_customerPhotosFactory = $customerPhotosFactory;
        $this->storeManager = $storeManager;
        $this->_encryptor = $encryptor;
        $this->_dataHelper = $dataHelper;
        $this->orderFactory = $orderFactory;
    }

    public function execute()
    {
        //echo "called admin"; exit;
        $this->resultPage = $this->resultPageFactory->create();

        try{

            // Customer ID

            $response_array = array();
            $extTypes = array('jpg','jpeg','png','heic');
            $customerId = $this->getRequest()->getParam('customer_id');
            $photoType = $this->getRequest()->getParam('photo_type');
            //$incrementId = $this->getRequest()->getParam('increment_id');

            // Directories Dynamically created.
            $dirPath = $this->createRecursiveDirectories($customerId, $photoType);
            
            if($this->getRequest()->getParam('photo_id') != "")
            {
                $photoId = $this->getRequest()->getParam('photo_id');
            }
            else
            {
                $photoId = null;
            }

//===================================================== FACE PHOTO UPLOAD CODE ========================================

            if(isset($photoType) && $photoType == 'full_face')
            {

                $face_files = $this->getRequest()->getFiles('face_photo');
                $photoType = $photoType;


                $fileName_facePhoto = ($face_files && array_key_exists('name', $face_files)) ? $face_files['name'] : null;
                $fileName_facePhoto = str_replace(" ", "_", strtolower($fileName_facePhoto));
                if ($face_files && $fileName_facePhoto) {


                    /** @var $uploader \Magento\MediaStorage\Model\File\UploaderFactory */
                    $uploader = $this->_fileUploaderFactory->create(['fileId' => 'face_photo']);

                    // set allowed file extensions
                    $uploader->setAllowedExtensions(['jpg','jpeg','png','heic']);

                    // Allow folder creation if not exists
                    $uploader->setAllowCreateFolders(true);

                    // Rename file if already exists it set true(like filename.jpg, filename_1.jpg etc), and set false it overrides into dir
                    $uploader->setAllowRenameFiles(false);

                    $fileName_facePhoto = preg_replace("/[^A-Za-z0-9-.]/", '_', $fileName_facePhoto);
                    $newStr = explode('.', $fileName_facePhoto);
                    $face_fileExt = end($newStr);

                    $imagePath = $dirPath.'/'.$customerId.'_'.$photoType.'_'.time().'.'.$face_fileExt;
                    $dirFullPath = $this->_dataHelper->getRootDirPath().$imagePath;
                    $photoPath = $this->_dataHelper->getRootPath().$imagePath;
                    
                    // =================== Image Resize before save to directory and db ==============================

                    
                    $uploadedFile = $face_files['tmp_name'];
                    $resizedImgURL = $this->_dataHelper->imageResizeBeforeSaveImage($dirFullPath, $uploadedFile);
                   
                    // =================== Image Resize before save to directory and db ==============================


                    // Old record needs to do be status zero of 'prescription_customer_photo' table
                    if($photoId != "" || $photoId != null )
                    {
                        $facesavephotoModel = $this->_customerPhotosFactory->create()->load($photoId);
                                $facesavephotoModel->setStatus(0)
                                                      ->save();
                    }

                    // New record will be adding by creating new Object
                    $facesavephotoModelNewObj = $this->_customerPhotosFactory->create();
                    $facesavephotoModelNewObj->setCustomerId($customerId)
                        ->setPhotoType($photoType)
                        ->setPath($imagePath)
                        ->setSourceSystem($face_files['tmp_name'])
                        ->setStatus(1)
                        //->setIncrementId($incrementId)
                        ->setCreatedAt(date('Y-m-d h:i:s'))
                        ->save();

                  

                }
                else
                {
                    $response_array['face_image_path'] = "";
                }



                // ============================== Image encrypted code start here ====================================

                $response_array['face_image_path'] = '';

                try{

                    if($photoPath != "" || $photoPath != null)
                    {
                        $response_array['face_image_path'] = '<a data-fancybox="gallery" href="'.$photoPath.'"><img src="'.$photoPath.'" style="max-height: 185px"></a>';
                        $response_array['face_image_success'] = 1;
                    }
                    else
                    {
                        $response_array['face_image_path'] = '';
                        $response_array['face_image_success'] = 2;
                    }

                    echo json_encode($response_array);
                    exit;


                }catch (\Exception $e) {

                    // echo $e->getMessage(); exit;
                    $response_array['face_image_success'] = 2;
                }
                // ============================== Image encrypted code end here ========================================
            }




//====================================================================== Govt PHOTOID UPLOAD CODE ==============================================================================================

            if(!empty($this->getRequest()->getParam('govt_photo_type')))
            {

                $files = $this->getRequest()->getFiles('govt_photo');
                $govtPhotoType = $this->getRequest()->getParam('govt_photo_type');



                $fileName = ($files && array_key_exists('name', $files)) ? $files['name'] : null;
                $fileName = str_replace(" ", "_", strtolower($fileName));
                if ($files && $fileName) {


                    /** @var $uploader \Magento\MediaStorage\Model\File\UploaderFactory */
                    $uploader = $this->_fileUploaderFactory->create(['fileId' => 'govt_photo']);

                    // set allowed file extensions
                    $uploader->setAllowedExtensions(['jpg','jpeg','png','heic']);

                    // Allow folder creation if not exists
                    $uploader->setAllowCreateFolders(true);

                    // Rename file if already exists it set true(like filename.jpg, filename_1.jpg etc), and set false it overrides into dir
                    $uploader->setAllowRenameFiles(false);


                    // ================== Encrypted filename with MD5 hase ========================

                    $fileName = preg_replace("/[^A-Za-z0-9-.]/", '_', $fileName);
                    $newStr = explode('.', $fileName);
                    $fileExt = end($newStr);
                    $fileNameWithoutExt = str_replace('.', '', $fileName);

                    $fileNameWithoutExt = md5($fileNameWithoutExt);
                    $fileName = $fileNameWithoutExt.'.'.$fileExt;

                    // ================== Encrypted filename with MD5 hase ========================



                    // =================== Image Resize before save to directory and db ==============================


                    // If image type is heic then
                    if($fileExt == 'heic')
                    {
                        // heic directory creation
                        $heicDir = $custDirPhotoId.'/heic';
                        if (!file_exists($heicDir)) {
                            mkdir($heicDir, 0777, true);
                        }

                        //echo $fileName; exit;
                        $result = $uploader->save(
                            $this->_mediaDirectory->getAbsolutePath().'images/govtIssuedPhoto/'.$customerId.'/heic', $fileName);
                        //print_r($result);
                        //exit;


                        $uploadedFile = $this->_mediaDirectory->getAbsolutePath().'images/govtIssuedPhoto/'.$customerId.'/heic/'.$fileName;


                        // code for Magick library start here

                        //$newFileName = $files['tmp_name'];
                        $newFileName = $uploadedFile;

                        $imagick = new \Imagick($newFileName);

                        //$imagick->clear();

                        // convert to jpg
                        $imagick->setImageFormat('jpg');
                        $imagick->readImage($newFileName);

                        $f_name_arr = explode('.', $fileName);
                        $f_name = $f_name_arr[0];   // extract name from '08563e541993a69209d4d3cf078861df.heic'
                        $fileName = $f_name.'.jpg';


                        $imagick->writeImage($this->_mediaDirectory->getAbsolutePath().'images/govtIssuedPhoto/'.$customerId.'/'.$fileName);


                        // code for Magick library end here

                        // Save image again out of 'heic' dir after resize
                        $uploadedFile = $this->_mediaDirectory->getAbsolutePath().'images/govtIssuedPhoto/'.$customerId.'/'.$fileName;

                        $resizedImgURL = $this->_dataHelper->imageResizeBeforeSaveImage($fileName, $uploadedFile, 'govtIssuedPhoto', $customerId);

                    }
                    else{

                        $uploadedFile = $files['tmp_name'];
                        $resizedImgURL = $this->_dataHelper->imageResizeBeforeSaveImage($fileName, $uploadedFile, 'govtIssuedPhoto', $customerId);
                    }

                    // =================== Image Resize before save to directory and db ==============================



                    // Old record needs to do be status zero of 'prescription_customer_photo' table
                    $photoModel = $this->_customerPhotosFactory->create();
                    if($photoId != "" || $photoId != null)
                    {

                        $photoModel->load($photoId)
                                   ->setStatus(0)
                                   ->save();
                    }

                    // New record will be adding by creating new Object
                   
                    $photoModelNewObj = $this->_customerPhotosFactory->create();
                    $photoModelNewObj->setCustomerId($customerId)
                                    ->setPhotoType($govtPhotoType)
                                    ->setPath($fileName)
                                    ->setSourceSystem($files['tmp_name'])
                                    ->setStatus(1)
                                    ->setIncrementId($incrementId)
                                    ->setCreatedAt(date('Y-m-d h:i:s'))
                                    ->save();


                }
                else
                {
                    $response_array['photoid_image_path'] = "";
                }



                // ============================== Image encrypted code start here ====================================

                $response_array['photoid_image_path'] = '';

                try{

                    //$url = '/var/www/enhance/pub/media/images/govtIssuedPhoto/'.$customerId.'/'.$fileName;
                    $url = $this->_dataHelper->getGovtPhotoDirUrl().$customerId.'/'.$fileName;
                    $type = pathinfo($url, PATHINFO_EXTENSION);
                    $data = file_get_contents($url);
                    $imageData = base64_encode($data);
                    $imagePath = 'data: '.mime_content_type($url).';base64,'.$imageData;


                    if($fileName != "" || $fileName != null)
                    {
                        $response_array['photoid_image_path'] = '<a data-fancybox="gallery" href="'.$imagePath.'"><img src="'.$imagePath.'" style="max-height: 185px"></a>';
                        //$response_array['govt_customerPhotoId'] = $newCustomerPhotoId_govtId;
                        $response_array['success'] = 1;


                    }
                    else
                    {
                        $response_array['photoid_image_path'] = '';
                        $response_array['success'] = 2;
                    }

                    echo json_encode($response_array);
                    exit;


                }catch (\Exception $e) {

                     echo $e->getMessage(); exit;
                    $response_array['errorMessage'] = $e->getMessage();
                    $response_array['success'] = 2;
                }

                // ============================== Image encrypted code end here ========================================
            }




        } catch (\Exception $e) {
            //echo $e->getMessage(); exit;
            $response_array['error'] = 1;
            $response_array['errorMessage'] = $e->getMessage();

            echo json_encode($response_array);
            exit;

            $this->_messageManager->addError('Only jpg, jpeg, png and heic file type is allowed.');
        }

        return $this->resultPage;
    }

    // Create directory and return path
    public function createRecursiveDirectories($customerId, $photoType) {

        $secureDir  =  $this->_dataHelper->getRootDirPath();
        if (!file_exists($secureDir)) {
            mkdir($secureDir, 0777, true);
        }

        // Required Dir 'customer' will create if not created
        /*$customerDir  =  $secureDir.'/customer';
        if (!file_exists($customerDir)) {
            mkdir($customerDir, 0777, true);
        }

        // Required Dir 'customer' will create if not created
        $photosDir  =  $customerDir.'/photos';
        if (!file_exists($photosDir)) {
            mkdir($photosDir, 0777, true);
        }*/
         
         $dirPath = "";
        for($i=0; $i < strlen($customerId); $i++) {

            $dirPath = $dirPath.'/'.$customerId[$i];

            if (!file_exists($secureDir.'/'.$customerId[$i])) {

               // $temp[$i-1] = $customerId[$i];
                mkdir($secureDir.'/'.$customerId[$i], 0777, true);
               // $photosDir = 
                $secureDir = $secureDir.'/'.$customerId[$i];

                //$customerDirPath .= $customerId[$i];
            }
        }
        return $dirPath;
    }
}

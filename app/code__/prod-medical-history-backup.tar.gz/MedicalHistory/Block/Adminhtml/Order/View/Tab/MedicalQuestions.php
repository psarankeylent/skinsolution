<?php

namespace Ssmd\MedicalHistory\Block\Adminhtml\Order\View\Tab;

class MedicalQuestions extends \Magento\Sales\Block\Adminhtml\Order\AbstractOrder implements
    \Magento\Backend\Block\Widget\Tab\TabInterface
{

    protected $orderFactory;
    protected $productFactory;
    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Sales\Helper\Admin $adminHelper
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Sales\Helper\Admin $adminHelper,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        \Magento\Catalog\Model\ProductFactory $productFactory,
        array $data = []
    ) {
        parent::__construct($context, $registry, $adminHelper, $data);
        $this->orderFactory = $orderFactory;
        $this->productFactory = $productFactory;
    }

    /**
     * Retrieve order model instance
     *
     * @return \Magento\Sales\Model\Order
     */
    public function getOrder()
    {
        return $this->_coreRegistry->registry('current_order');
    }
    /**
     * {@inheritdoc}
     */
    public function getTabLabel()
    {
        return __('Medical History');
    }

    /**
     * {@inheritdoc}
     */
    public function getTabTitle()
    {
        return __('Medical History');
    }

    /**
     * {@inheritdoc}
     */
    public function canShowTab()
    {
        /*
        $order = $this->getOrder();
        $orderId =  $order->getId();
        $uniqueId=null;

        $order = $this->orderFactory->create()->load($orderId);
        $uniqueId = $order->getData('unique_id');

        if(isset($uniqueId) && $uniqueId != "")
        {
            return true;
        }
        else
        {
            return false;
        }
        */


        $canShowTab = false;
        $orderId = $this->getOrder()->getId();
        //$orderId =  $order->getId();
        $order = $this->orderFactory->create()->load($orderId);

        foreach ($order->getAllItems() as $item){
            //$row = [];
            $productId =  $item->getProductId();
            $product = $this->productFactory->create()->load($productId);
            if($product->getPrescription()){
                $canShowTab = true;
            }

        }

        return $canShowTab;



    }

    /**
     * {@inheritdoc}
     */
    public function isHidden()
    {
        return false;
    }
}



<?php

namespace Ssmd\MedicalHistory\Block\Adminhtml\Customer\Edit\Tab;

use Magento\Backend\Block\Widget\Form\Generic;
use Magento\Backend\Block\Template;

class MedicalHistory extends Generic implements \Magento\Ui\Component\Layout\Tabs\TabInterface
{

    /**
     * Template
     *
     * @var string
     */
    protected $_template = 'tab/customer_history.phtml';

    protected $medicalHistoryFactory;
    protected $orderFactory;
    protected $resourceCollection;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Ssmd\MedicalHistory\Model\CustomerMedicalHistoryFactory $medicalHistoryFactory,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        \Magento\Framework\App\ResourceConnection $resourceCollection,
        array $data = []
    ) {
        parent::__construct($context, $registry, $formFactory, $data);
        $this->medicalHistoryFactory = $medicalHistoryFactory;
        $this->_coreRegistry = $registry;
        $this->orderFactory = $orderFactory;
        $this->resourceCollection = $resourceCollection;
    }

    /**
     * @return string|null
     */
    public function getCustomerId()
    {
        return $this->_coreRegistry->registry(\Magento\Customer\Controller\RegistryConstants::CURRENT_CUSTOMER_ID);
    }
    /**
     * @return \Magento\Framework\Phrase
     */
    public function getTabLabel()
    {
        return __('Medical History');
    }

    /**
     * @return \Magento\Framework\Phrase
     */
    public function getTabTitle()
    {
        return __('Medical History');
    }

    /**
     * @return bool
     */
    public function canShowTab()
    {
        if ($this->getCustomerId()) {
            return true;
        }
        return false;
    }

    /**
     * @return bool
     */
    public function isHidden()
    {
        if ($this->getCustomerId()) {
            return false;
        }
        return true;
    }

    /**
     * Tab class getter
     *
     * @return string
     */
    public function getTabClass()
    {
        return '';
    }

    /**
     * Return URL link to Tab content
     *
     * @return string
     */
    public function getTabUrl()
    {
        return '';
    }

    /**
     * Tab should be loaded trough Ajax call
     *
     * @return bool
     */
    public function isAjaxLoaded()
    {
        return false;
    }


    // Return data array of Customer Medical Histroy
    public function getMedicalHistoryByCustomer()
    {
        $customerId = $this->getCustomerId();

        $medicalHistoryCollection = $this->medicalHistoryFactory->create()->getCollection();
        $medicalHistoryCollection->addFieldToFilter('customer_id', $customerId);
        //$medicalHistoryCollection->setOrder('id','DESC');

        $data = $medicalHistoryCollection->getData();

        //echo "<pre>"; print_r($data);  exit;
        return $data;

    }

    // Return data array of Customer Medical Histroy
    public function getMedicalHistoryByCustomerGroupByOrder()
    {
        $customerId = $this->getCustomerId();
        //$customerId = 241213;

        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/medicalHistorylog.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        //$logger->info("Something were wrong!");

        try {

            $medicalHistoryCollection = $this->medicalHistoryFactory->create()->getCollection();
            $medicalHistoryCollection->addFieldToFilter('customer_id', $customerId);
            $medicalHistoryCollection->setOrder('id','DESC');

            $dt = $medicalHistoryCollection->getFirstItem();
            //echo "<pre>"; print_r($dt->getData()); exit;
            $results=[];
            if(!empty($dt->getData()))
            {
                $maxOrderNumber = $dt->getData()['order_number'];

                if(isset($maxOrderNumber) && $maxOrderNumber != "")
                {
                    $medicalHistoryCollection = $this->medicalHistoryFactory->create()->getCollection();
                    $medicalHistoryCollection->addFieldToFilter('customer_id', $customerId);
                    $medicalHistoryCollection->addFieldToFilter('order_number', $maxOrderNumber);

                    //echo "<pre>"; print_r($results=$medicalHistoryCollection->getData()); exit;
                    $results=$medicalHistoryCollection->getData();
                }
                else
                {
                    throw new \Exception("Order Number Not Found.", 1);
                }
            }
            return $results;
        }
        catch(\Exception $e){
            $logger->info("Error : ".$e->getMessage());
        }
    }

}



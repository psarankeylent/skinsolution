<?php

namespace Ssmd\CustomerNotes\Model\ResourceModel\CustomerNote;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
	
	protected $_idFieldName = 'id';
	/**
	 * Define resource model
	 *
	 * @return void
	 */
	protected function _construct()
	{
		$this->_init('Ssmd\CustomerNotes\Model\CustomerNote', 'Ssmd\CustomerNotes\Model\ResourceModel\CustomerNote');
	}
	
}

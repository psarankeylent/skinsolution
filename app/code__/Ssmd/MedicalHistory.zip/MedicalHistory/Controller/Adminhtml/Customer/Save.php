<?php
namespace Ssmd\MedicalHistory\Controller\Adminhtml\Customer;

use Magento\Customer\Api\Data\GroupInterface;
use Magento\Framework\Api\ExtensionAttributesInterface\Config;

class Save extends \Magento\Backend\App\Action
{
    protected $_responseFactory;
    protected $_url;
    protected $medicalHistoryFactory;
    protected $resource;

    public function __construct(
        \Magento\Framework\HTTP\Client\Curl $curl,
        \VirtualHub\Config\Helper\Config $configHelper,
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\App\ResponseFactory $responseFactory,
        \Magento\Framework\UrlInterface $url,
        \Ssmd\MedicalHistory\Model\CustomerMedicalHistoryFactory $medicalHistoryFactory,
        \Magento\Framework\App\ResourceConnection $resource
    ) {
        $this->curl = $curl;
        $this->configHelper = $configHelper;        
        $this->_responseFactory = $responseFactory;
        $this->_url = $url;
        $this->medicalHistoryFactory = $medicalHistoryFactory;
        $this->resource = $resource;
        parent::__construct($context);
    }

    public function execute()
    {
        $params = $this->getRequest()->getParams();
        $customerId = $params['customer_id'];

        if(isset($customerId) && $customerId != "")
        {

            // Code for update multiple data
            try {

                $connection = $this->resource->getConnection();

                $condition=null;
                $quesId = null;
                $quesText = null;
                $response = null;

                foreach ($params as $key => $value)
                {
                    $keyArr = preg_split('~-(?=[^-]*$)~', $key);   // If string contains multiple[-], explode only last occurance

                    $keyArr[0] = trim($keyArr[0], '_');  // Remove spaces from start & end string.

                    if($keyArr[0] == 'key')
                    {
                        continue;
                    }
                    if($keyArr[0] == 'First_Name')
                    {

                        $condition = "`customer_id`= $customerId AND `question_id`= 1 AND `id`= $keyArr[1] ";

                        $dataArray = [
                            'question_id' => 1,
                            'response' => $value
                        ];

                        $this->setTableRecords($condition, $dataArray);

                    }
                    else if($keyArr[0] == 'Last_Name')
                    {
                        $condition = "`customer_id`= $customerId AND `question_id`= 2 AND `id`= $keyArr[1] ";

                        $dataArray = [
                            'question_id' => 2,
                            'response' => $value
                        ];

                        $this->setTableRecords($condition, $dataArray);
                    }
                    else if($keyArr[0] == 'Gender')
                    {
                        $condition = "`customer_id`= $customerId AND `question_id`= 3 AND `id`= $keyArr[1] ";

                        $dataArray = [
                            'question_id' => 3,
                            'response' => $value
                        ];

                        $this->setTableRecords($condition, $dataArray);
                    }
                    else if($keyArr[0] == 'Pregnant_or_breastfeeding')
                    {
                        $condition = "`customer_id`= $customerId AND `question_id`= 4 AND `id`= $keyArr[1] ";

                        $dataArray = [
                            'question_id' => 4,
                            'response' => $value
                        ];

                        $this->setTableRecords($condition, $dataArray);
                    }
                    else if($keyArr[0] == 'Date_of_Birth')
                    {
                        $condition = "`customer_id`= $customerId AND `question_id`= 5 AND `id`= $keyArr[1] ";

                        $dataArray = [
                            'question_id' => 5,
                            'response' => $value
                        ];

                        $this->setTableRecords($condition, $dataArray);
                    }
                    else if($keyArr[0] == 'Phone_Number')
                    {
                        $condition = "`customer_id`= $customerId AND `question_id`= 6 AND `id`= $keyArr[1] ";

                        $dataArray = [
                            'question_id' => 6,
                            'response' => $value
                        ];

                        $this->setTableRecords($condition, $dataArray);
                    }
                    else if($keyArr[0] == "Physician's_Name")
                    {
                        $condition = "`customer_id`= $customerId AND `question_id`= 7 AND `id`= $keyArr[1] ";

                        $dataArray = [
                            'question_id' => 7,
                            'response' => $value
                        ];

                        $this->setTableRecords($condition, $dataArray);
                    }
                    else if($keyArr[0] == "Physician's_Phone")
                    {
                        $condition = "`customer_id`= $customerId AND `question_id`= 8 AND `id`= $keyArr[1] ";

                        $dataArray = [
                            'question_id' => 8,
                            'response' => $value
                        ];

                        $this->setTableRecords($condition, $dataArray);
                    }
                    else if($keyArr[0] == "Physician's_Email")
                    {
                        $condition = "`customer_id`= $customerId AND `question_id`= 9 AND `id`= $keyArr[1] ";

                        $dataArray = [
                            'question_id' => 9,
                            'response' => $value
                        ];

                        $this->setTableRecords($condition, $dataArray);
                    }
                    else if($keyArr[0] == "List_any_MEDICAL_CONDITIONS")
                    {
                        $condition = "`customer_id`= $customerId AND `question_id`= 10 AND `id`= $keyArr[1] ";

                        $dataArray = [
                            'question_id' => 10,
                            'response' => $value
                        ];

                        $this->setTableRecords($condition, $dataArray);
                    }
                    else if($keyArr[0] == "List_any_MEDICATIONS_you_are_currently_taking_(including_eye_drops)")
                    {
                        $condition = "`customer_id`= $customerId AND `question_id`= 11 AND `id`= $keyArr[1] ";

                        $dataArray = [
                            'question_id' => 11,
                            'response' => $value
                        ];

                        $this->setTableRecords($condition, $dataArray);
                    }
                    else if($keyArr[0] == "List_any_ALLERGIES_to_medications")
                    {
                        $condition = "`customer_id`= $customerId AND `question_id`= 12 AND `id`= $keyArr[1] ";

                        $dataArray = [
                            'question_id' => 12,
                            'response' => $value
                        ];

                        $this->setTableRecords($condition, $dataArray );
                    }
                    else if($keyArr[0] == "Eye_problems")
                    {

                        $condition = "`customer_id`= $customerId AND `question_id`= 13 AND `id`= $keyArr[1] ";

                        $dataArray = [
                            'question_id' => 13,
                            'response' => $value
                        ];

                        $this->setTableRecords($condition, $dataArray );
                    }
                    else if($keyArr[0] == "Have_you_ever_used_Latisse_in_the_past?")
                    {
                        $quesId = 14;
                        $quesText = "List any MEDICATIONS you are currently taking (including eye drops).";
                        $response = $value;

                        $condition = "`customer_id`= $customerId AND `question_id`= 14 AND `id`= $keyArr[1] ";

                        $dataArray = [
                            'question_id' => 14,
                            'response' => $value
                        ];

                        $this->setTableRecords($condition, $dataArray );
                    }
                    else if($keyArr[0] == "List_any_skin_concerns_or_goals")
                    {

                        $condition = "`customer_id`= $customerId AND `question_id`= 15 AND `id`= $keyArr[1] ";

                        $dataArray = [
                            'question_id' => 15,
                            'response' => $value
                        ];

                        $this->setTableRecords($condition, $dataArray );
                    }
                    else if($keyArr[0] == "Describe_skin_type")
                    {
                        $condition = "`customer_id`= $customerId AND `question_id`= 16 AND `id`= $keyArr[1] ";

                        $dataArray = [
                            'question_id' => 16,
                            'response' => $value
                        ];

                        $this->setTableRecords($condition, $dataArray );
                    }
                    else if($keyArr[0] == "How_often_do_you_wear_sunscreen?")
                    {
                        $condition = "`customer_id`= $customerId AND `question_id`= 17 AND `id`= $keyArr[1] ";

                        $dataArray = [
                            'question_id' => 17,
                            'response' => $value
                        ];

                        $this->setTableRecords($condition, $dataArray );
                    }
                    else if($keyArr[0] == "Are_you_using_a_product_containing_a_non-prescription_retinoid,_such_as_retinol_or_retinyl_palmitate?")
                    {

                        $condition = "`customer_id`= $customerId AND `question_id`= 18 AND `id`= $keyArr[1] ";

                        $dataArray = [
                            'question_id' => 18,
                            'response' => $value
                        ];

                        $this->setTableRecords($condition, $dataArray );
                    }
                    else if($keyArr[0] == "Have_you_used_any_prescription_topicals_(cream,_gel,_etc)_for_acne,_skin_lightening_or_aging?")
                    {
                        $condition = "`customer_id`= $customerId AND `question_id`= 19 AND `id`= $keyArr[1] ";

                        $dataArray = [
                            'question_id' => 19,
                            'response' => $value
                        ];

                        $this->setTableRecords($condition, $dataArray );
                    }
                    else if($keyArr[0] == "Have_you_used_Upneeq_in_the_past?")
                    {
                        $condition = "`customer_id`= $customerId AND `question_id`= 20 AND `id`= $keyArr[1] ";

                        $dataArray = [
                            'question_id' => 20,
                            'response' => $value
                        ];

                        $this->setTableRecords($condition, $dataArray );
                    }
                    else if($keyArr[0] == "Do_you_take_medication_for_high_blood_pressure?")
                    {
                        $condition = "`customer_id`= $customerId AND `question_id`= 21 AND `id`= $keyArr[1] ";

                        $dataArray = [
                            'question_id' => 21,
                            'response' => $value
                        ];

                        $this->setTableRecords($condition, $dataArray );
                    }
                    else if($keyArr[0] == "Do_you_take_medication_for_depression?")
                    {
                        $condition = "`customer_id`= $customerId AND `question_id`= 23 AND `id`= $keyArr[1] ";

                        $dataArray = [
                            'question_id' => 23,
                            'response' => $value
                        ];

                        $this->setTableRecords($condition, $dataArray );
                    }
                    else if( ($keyArr[0] == "Do_you_have_Sjogrenâ€™s_syndrome?")||($keyArr[0] == "Do_you_have_Sjogren's_syndrome?") )
                    {
                        $condition = "`customer_id`= $customerId AND `question_id`= 24 AND `id`= $keyArr[1] ";

                        $dataArray = [
                            'question_id' => 24,
                            'response' => $value
                        ];

                        $this->setTableRecords($condition, $dataArray );
                    }
                    else if($keyArr[0] == "Do_your_low-lying_eyelids_interfere_with_any_day-to-day_functions?")
                    {

                        $condition = "`customer_id`= $customerId AND `question_id`= 25 AND `id`= $keyArr[1] ";

                        $dataArray = [
                            'question_id' => 25,
                            'response' => $value
                        ];

                        $this->setTableRecords($condition, $dataArray );
                    }
                    else if($keyArr[0] == "Do_you_have_unwanted_facial_hair?")
                    {
                        $condition = "`customer_id`= $customerId AND `question_id`= 26 AND `id`= $keyArr[1] ";

                        $dataArray = [
                            'question_id' => 26,
                            'response' => $value
                        ];

                        $this->setTableRecords($condition, $dataArray );
                    }
                    else if($keyArr[0] == "Have_you_used_vaniqa_in_the_past?")
                    {
                        $condition = "`customer_id`= $customerId AND `question_id`= 27 AND `id`= $keyArr[1] ";

                        $dataArray = [
                            'question_id' => 27,
                            'response' => $value
                        ];

                        $this->setTableRecords($condition, $dataArray );
                    }
                    else if($keyArr[0] == "Other_hair_removal_methods_used")
                    {
                        $quesId = 28;
                        $quesText = "List any MEDICATIONS you are currently taking (including eye drops).";
                        $response = $value;

                        $condition = "`customer_id`= $customerId AND `question_id`= 28 AND `id`= $keyArr[1] ";

                        $dataArray = [
                            'question_id' => 28,
                            'response' => $value
                        ];

                        $this->setTableRecords($condition, $dataArray );
                    }
                }


                $this->messageManager->addSuccess( __('You saved the customer medical history.') );
                // code for sending data to virtual hub //

                $request['customer_id'] = $customerId;                
                $bearerToken = $this->configHelper->getVirtualHubBearerToken();
                $vhUrl = "https://stage.zeelify.md/api/v1/ssmdupdatemedicalinfo";
                if($bearerToken['success'] == True){
                    $token = $bearerToken['token'];
                    //$vhUrl = $this->configHelper->getConsultOnlyStatus();
                    $headers = ["Content-Type" => "application/json", "Authorization" => 'Bearer '.$token];
                    $this->curl->setHeaders($headers);
                    $this->curl->post($vhUrl, json_encode($request));
                    $response = $this->curl->getBody();

                    $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/medical_history_admin_edit_response.log');
                    $logger = new \Zend\Log\Logger();
                    $logger->addWriter($writer);
                    $logger->info($response);
                }


            } catch (\Exception $e) {
                $this->messageManager->addException($e, __('Something went wrong while saving the data.'));
            }

        }
        else
        {
            $this->messageManager->addErrorMessage(__('Customer not found.'));
        }

        $this->_redirect('customer/index/edit/id/'.$customerId);

    }

    // Update Data for given condition for collection of table M2 customer_medical_history
    public function setTableRecords($condition, $columnData){
        return $this->resource->getConnection()->update('customer_medical_history', $columnData, $where = $condition);
    }


}

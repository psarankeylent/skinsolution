<?php

namespace Ssmd\MedicalHistory\Block\Adminhtml\Order\View;

use Magento\Backend\Block\Template\Context;
use Magento\Framework\Registry;
use Magento\Backend\Block\Template;
//use Enhance\Prescriptions\Model\CustomerPrescriptionOrders as CustomerPrescriptionOrders;

class Refill extends Template
{
    protected $medicalHistoryHelper;
    protected $resultJsonFactory;
    protected $_customerVisitor;
    protected $orderFactory;
    protected $medicalHistoryFactory;

    public function __construct(
        Context $context,
        Registry $registry,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        \Ssmd\MedicalHistory\Helper\Data $medicalHistoryHelper,
        \Ssmd\MedicalHistory\Model\CustomerMedicalHistoryFactory $medicalHistoryFactory
    )
    {
        $this->_registry = $registry;
        $this->orderFactory = $orderFactory;
        $this->medicalHistoryHelper = $medicalHistoryHelper;
        $this->medicalHistoryFactory = $medicalHistoryFactory;
        return parent::__construct($context);
    }
    /**
     * Retrieve order model instance
     *
     * @return \Magento\Sales\Model\Order
     */
    public function getOrder()
    {
        return $this->_registry->registry('current_order');
    }
    
    // Return data array of Customer Medical Histroy
    public function getMedicalHistoryByOrder(){
        $order = $this->getOrder();
        
        $medicalHistoryCollection = $this->medicalHistoryFactory->create()->getCollection();
        $medicalHistoryCollection->addFieldToFilter('order_number', $order->getData('increment_id'));
        $data = $medicalHistoryCollection->getData();
        return $data;

    }

}

While "Unit tests 7.2" pipeline fails because of usage of Laminas-classes within the project, UNIT tests will be checked 

for Magento 2.4.*

only

Temporary solution by starodinov@aheadworks.com 
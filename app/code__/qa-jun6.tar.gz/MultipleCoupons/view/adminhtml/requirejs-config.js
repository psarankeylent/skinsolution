var config = {
    map: {
        '*': {
            'Magento_Sales/order/create/scripts':'Ssmd_MultipleCoupons/js/order/create/scripts'
        }
    }
};
